/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package proyecto2.pkg1;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


/**
 * Clase que gestiona los empleados permite agregar,
 * eliminar y ver empleados
 * Cada empleado contiene: ID, Nombre, Apellido y Teléfono.
 * @author sheyr
 */
public class Empleos extends javax.swing.JFrame {
    
    DefaultTableModel tEmpleados;
    public static String[][] empleados = new String[100][4]; // Máximo 100 empleados
    public static int contador = 0;

    /**
     * Constructor
     */
    public Empleos() {
        initComponents();
        tEmpleados =new DefaultTableModel();
        tEmpleados.addColumn("Id");
        tEmpleados.addColumn("Nombre");
        tEmpleados.addColumn("Apellido");
        tEmpleados.addColumn("Telefono");
        this.tabla.setModel(tEmpleados);  
    }
    
    
    
    
    
     public void mostrarListaEmpleados() {
          if (contador == 0) {
             JOptionPane.showMessageDialog(this, "No hay empleados registrados.");
             return;
         }
             //StringBuilder ayuda a crear cadena Strings
             StringBuilder lista = new StringBuilder(); 
              for (int i = 0; i < contador; i++) {
                  lista.append("Empleado ").append(i + 1).append(":\n");
                  lista.append("ID: ").append(empleados[i][0]).append("\n");
                  lista.append("Nombre: ").append(empleados[i][1]).append("\n");
                  lista.append("Apellido: ").append(empleados[i][2]).append("\n");
                  lista.append("Teléfono: ").append(empleados[i][3]).append("\n\n");
                 }
            JOptionPane.showMessageDialog(this, lista.toString());

     }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        tNombre = new javax.swing.JTextField();
        tApellido = new javax.swing.JTextField();
        tNumero = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabla = new javax.swing.JTable();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        jLabel1.setBackground(new java.awt.Color(102, 204, 255));
        jLabel1.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Nombre");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(86, 11, 63, 22);

        jLabel2.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Apellidos");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(86, 52, 80, 22);

        jLabel3.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Telefono");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(86, 87, 69, 22);
        getContentPane().add(tNombre);
        tNombre.setBounds(313, 12, 216, 22);
        getContentPane().add(tApellido);
        tApellido.setBounds(313, 53, 216, 22);
        getContentPane().add(tNumero);
        tNumero.setBounds(313, 88, 216, 22);

        jButton1.setBackground(new java.awt.Color(102, 204, 255));
        jButton1.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jButton1.setForeground(java.awt.Color.white);
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Agregar.png"))); // NOI18N
        jButton1.setText("Insertar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(15, 128, 130, 31);

        jButton2.setBackground(new java.awt.Color(102, 204, 255));
        jButton2.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jButton2.setForeground(new java.awt.Color(255, 255, 255));
        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/eliminar.png"))); // NOI18N
        jButton2.setText("Eliminar");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2);
        jButton2.setBounds(159, 128, 140, 31);

        jButton3.setBackground(new java.awt.Color(102, 204, 255));
        jButton3.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jButton3.setForeground(java.awt.Color.white);
        jButton3.setText("Eliminar Todo");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3);
        jButton3.setBounds(310, 130, 150, 30);

        tabla.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(tabla);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(6, 171, 651, 239);

        jButton4.setBackground(new java.awt.Color(102, 204, 255));
        jButton4.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jButton4.setForeground(java.awt.Color.white);
        jButton4.setText("Regresar");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton4);
        jButton4.setBounds(550, 430, 120, 40);

        jButton5.setBackground(new java.awt.Color(102, 204, 255));
        jButton5.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jButton5.setForeground(java.awt.Color.white);
        jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/revisar.png"))); // NOI18N
        jButton5.setText("Ver empleados");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton5);
        jButton5.setBounds(475, 128, 190, 31);

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Fondo.jpg"))); // NOI18N
        getContentPane().add(jLabel4);
        jLabel4.setBounds(0, 0, 690, 480);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        //Arreglo
        String []emple = new String[4];
        emple[0] = String.valueOf(contador + 1);
        emple[1] = tNombre.getText().trim();
        emple[2] = tApellido.getText().trim();
        emple[3] = tNumero.getText().trim();
        tEmpleados.addRow(emple);
        

        //Variables           
        String nombre = tNombre.getText().trim();
        String apellido = tApellido.getText().trim();
        String telefonoS = tNumero.getText().trim();

    // Validar si todos los campos están llenos
    if (nombre.isEmpty() || apellido.isEmpty() || telefonoS.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Todos los campos deben estar llenos.");
        return;  
    }

    //convertir telefono a int
    int telefono;
    try {
        telefono = Integer.parseInt(telefonoS); 
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(this, "El teléfono debe ser un número válido.", "Error", JOptionPane.ERROR_MESSAGE);
        return; 
    }
           if (apellido.isEmpty() || telefonoS.isEmpty() || nombre.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Todos los campos deben estar llenos.", "Error", JOptionPane.ERROR_MESSAGE);
        return; 
    }
           
           
           
        // guardar los datos en arreglo
        if (contador < empleados.length) {
        empleados[contador][0] = emple[0];
        empleados[contador][1] = emple[1];
        empleados[contador][2] = emple[2];
        empleados[contador][3] = emple[3];
        contador++;
         } else {
             JOptionPane.showMessageDialog(null, "Límite de empleados alcanzado");
            }
        
        
        // para vaciar los datos ingresados jtable
        tNombre.setText("");
        tApellido.setText("");
        tNumero.setText("");
        this.tabla.setModel(tEmpleados);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
          //eleminar empleado
        int fila=tabla.getSelectedRow();
        if (fila >= 0) {
            tEmpleados.removeRow(fila);  
            
          //eliminar del arreglo  
         for (int i = fila; i < contador - 1; i++) {
            empleados[i][0] = empleados[i + 1][0];
            empleados[i][1] = empleados[i + 1][1];
            empleados[i][2] = empleados[i + 1][2];
            empleados[i][3] = empleados[i + 1][3];
        }
        //limpiar ultima fila
        empleados[contador - 1][0] = null;
        empleados[contador - 1][1] = null;
        empleados[contador - 1][2] = null;
        empleados[contador - 1][3] = null;

        // Decrementar el contador que es el ID
        contador--;
        }
        else{
            JOptionPane.showMessageDialog(null, "seleccionar fila");
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        //Eliminar todo de la lista
        int fila = tabla.getRowCount();
        for (int i = fila-1; i >= 0; i--) {
            tEmpleados.removeRow(i);        
        }
        
        for (int i = 0; i < empleados.length; i++) {
            for (int j = 0; j < empleados[i].length; j++) {
                empleados[i][j] = null;
            }
        }
        contador = 0;
        
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
        // salir al menu principal
        Menu menu = new Menu();
        menu.setVisible(true);
        this.dispose();
                 
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        // TODO add your handling code here:
        mostrarListaEmpleados();
    }//GEN-LAST:event_jButton5ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Empleos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Empleos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Empleos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Empleos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Empleos().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField tApellido;
    private javax.swing.JTextField tNombre;
    private javax.swing.JTextField tNumero;
    private javax.swing.JTable tabla;
    // End of variables declaration//GEN-END:variables
}
